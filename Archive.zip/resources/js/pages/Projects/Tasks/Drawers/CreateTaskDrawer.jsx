import { openConfirmModal } from '@/components/ConfirmModal';
import Dropzone from '@/components/Dropzone';
import CommentItem from '@/components/CommentItem';
import NewCommentForm from '@/components/NewCommentForm';
import RichTextEditor from '@/components/RichTextEditor';
import useTaskDrawerStore from '@/hooks/store/useTaskDrawerStore';
import useForm from '@/hooks/useForm';
import { hasRoles } from '@/utils/user';
import { usePage } from '@inertiajs/react';
import Comments from './Comments';
import {
  Button,
  Checkbox,
  Drawer,
  Flex,
  MultiSelect,
  NumberInput,
  Select,
  Text,
  TextInput,
  rem,
} from '@mantine/core';
import { DateInput } from '@mantine/dates';
import { useEffect } from 'react';
import LabelsDropdown from './LabelsDropdown';
import classes from './css/TaskDrawer.module.css';
import { PricingType } from '@/utils/enums';

function generateServiceCode() {
  const pad = n => n.toString().padStart(2, '0');
  const now = new Date();
  const y = now.getFullYear();
  const m = pad(now.getMonth() + 1);
  const d = pad(now.getDate());
  const H = pad(now.getHours());
  const i = pad(now.getMinutes());
  const s = pad(now.getSeconds());
  return `PLYN-${y}${m}${d}${H}${i}${s}`;
}

export function CreateTaskDrawer() {
 
  let initialComments = [];
  const { create, closeCreateTask } = useTaskDrawerStore();
  const {
    usersWithAccessToProject,
    taskGroups,
    labels,
    jobTitles,
    masterJenisPelayanans,
    project,
    currency,
    auth: { user },
  } = usePage().props;

  const initial = {
    code: generateServiceCode(),
    group_id: create.group_id ? create.group_id.toString() : '',
    code_jenis_pelayanan: '',   
    assigned_to_user_id: '',
    name: '',
    email: '',
    description: '',
    final_feedback: '',
    link_file_requirement: '',
    link_file_result: '',
    pricing_type: project?.default_pricing_type || PricingType.HOURLY,
    estimation: 0,
    fixed_price: '',
    due_on: '',
    hidden_from_clients: false,
    billable: true,
    subscribed_users: [user.id.toString()],
    labels: [],
    attachments: [],
    job_title: '',
    identity_number: '',
  };

  const [form, submit, updateValue] = useForm(
    'post',
    route('projects.tasks.store', [route().params.project]),
    {
      ...initial,
    }
  );

  function handleDelete(id) {
    setComments((prev) => prev.filter((c) => c.id !== id));
  }

  useEffect(() => {
    updateValue({ ...initial });
  }, [create.opened]);

  const closeDrawer = (force = false) => {
    if (force || (JSON.stringify(form.data) === JSON.stringify(initial) && !form.processing)) {
      closeCreateTask();
    } else {
      openConfirmModal({
        type: 'danger',
        title: 'Buang perubahan?',
        content: `Semua perubahan yang belum disimpan akan hilang.`,
        confirmLabel: 'Buang',
        confirmProps: { color: 'red' },
        onConfirm: () => closeCreateTask(),
      });
    }
  };

  const removeAttachment = index => {
    const files = [...form.data.attachments];
    files.splice(index, 1);
    updateValue('attachments', files);
  };

  const pricingTypes = [
    { value: PricingType.HOURLY, label: 'Hourly' },
    { value: PricingType.FIXED, label: 'Fixed' },
  ];

  const isFixedPrice = form.data.pricing_type === PricingType.FIXED;
  const currencySymbol = currency?.symbol || '';

  return (
    <Drawer
      opened={create.opened}
      onClose={closeDrawer}
      title={
        <Text
          fz={rem(28)}
          fw={600}
          ml={25}
          my='sm'
        >
          Buat Pelayanan Baru
        </Text>
      }
      position='right'
      size={1000}
      overlayProps={{ backgroundOpacity: 0.55, blur: 3 }}
      transitionProps={{
        transition: 'slide-left',
        duration: 400,
        timingFunction: 'ease',
      }}
    >
      <form
        onSubmit={event =>
          submit(event, {
            onSuccess: () => closeDrawer(true),
            forceFormData: true,
          })
        }
        className={classes.inner}
      >
        <div className={classes.content}>
          <TextInput
            label='Kode Pelayanan'
            readOnly
            value={form.data.code}
            onChange={() => {}}
            error={form.errors.code}
          />
          <TextInput
            label='Penerima Pelayanan'
            readOnly
            mt='xl'
            value={user.name}
          />
          <TextInput
            label='Nama Pemohon'
            placeholder='Nama Pemohon'
            required
            data-autofocus
            value={form.data.name}
            onChange={e => updateValue('name', e.target.value)}
            error={form.errors.name}
          />

          <TextInput
            label='NIM / Nomor Identitas lain'
            placeholder='NIM / Nomor Identitas lain Pemohon'
            required
             mt='xl'
            data-autofocus
            value={form.data.identity_number}
            onChange={e => updateValue('identity_number', e.target.value)}
            error={form.errors.identity_number}
          />

           <TextInput
            mt='xl'
            type='email'
            label='Email Pemohon'
            placeholder='Email Pemohon'
            value={form.data.email}
            onChange={e => updateValue('email', e.target.value)}
            error={form.errors.email}
          />
          
          <Select
            label='Pemohon Sebagai'
            placeholder='Pilih pemohon sebagai'
            required
            searchable
            mt='xl'
            clearable
            value={form.data.job_title}
            onChange={value =>
              form.setData('job_title', value)
            }
            data={jobTitles.map(job => ({
              value: job.code.toString(),
              label: job.name,
            }))}
            error={form.errors.job_title}
          />

          <Select
            label='Jenis Pelayanan'
            placeholder='Pilih jenis pelayanan'
            required
            searchable
            mt='xl'
            clearable
            value={form.data.code_jenis_pelayanan}
            onChange={value => updateValue('code_jenis_pelayanan', value)}
            data={masterJenisPelayanans.map(i => ({
              value: i.code,
              label: i.name,
            }))}
            error={form.errors.code_jenis_pelayanan}
          />

          

          <TextInput
            label='Link File Kebutuhan Pelayanan'
            placeholder='Link File Kebutuhan Pelayanan'
            mt='xl'
            value={form.data.link_file_requirement}
            onChange={e => updateValue('link_file_requirement', e.target.value)}
            error={form.errors.link_file_requirement}
          />
          <Text
            fz='sm'
            fw={500}
            mt='xl'
          >
            Deskripsi Pelayanan
          </Text>
          <RichTextEditor
            mt='xl'
            placeholder='Deskripsi Pelayanan'
            height={260}
            onChange={content => updateValue('description', content)}
          />

          <Text
            fz='sm'
            fw={500}
            mt='xl'
          >
            Feedback Akhir Pelayanan
          </Text>
          <RichTextEditor
            placeholder='Feedback Akhir Pelayanan'
            height={260}
            onChange={content => updateValue('final_feedback', content)}
          />
          <TextInput
            label='Link File Hasil Pelayanan'
            placeholder='Link File Hasil Pelayanan'
            mt='xl'
            value={form.data.link_file_result}
            onChange={e => updateValue('link_file_result', e.target.value)}
            error={form.errors.link_file_result}
          />
          {/* <NewCommentForm
            mt='xl'
            initialComments={initialComments}
            onSubmit={comment => setComments([...comments, comment])}
          /> */}

          {/* <Dropzone
            mt='xl'
            selected={form.data.attachments}
            onChange={files => updateValue('attachments', files)}
            remove={index => removeAttachment(index)}
          /> */}
          
          {/* <MultiSelect
            label='Penerima Notifikasi'
            placeholder='Pilih penerima notifikasi'
            searchable
            mt='md'
            value={form.data.subscribed_users}
            onChange={values => updateValue('subscribed_users', values)}
            data={usersWithAccessToProject.map(i => ({
              value: i.id.toString(),
              label: i.name,
            }))}
            error={form.errors.subscribed_users}
          /> */}

          <Flex
            justify='space-between'
            mt='xl'
          >
            <Button
              variant='transparent'
              w={100}
              disabled={form.processing}
              onClick={closeDrawer}
            >
              Batal
            </Button>

            <Button
              type='submit'
              w={170}
              loading={form.processing}
            >
              Tambah Pelayanan
            </Button>
          </Flex>
        </div>
        <div className={classes.sidebar}>
          <Select
            label='Status Pelayanan'
            placeholder='Pilih Status Pelayanan'
            required
            value={form.data.group_id}
            onChange={value => updateValue('group_id', value)}
            data={taskGroups.map(i => ({
              value: i.id.toString(),
              label: i.name,
            }))}
            error={form.errors.group_id}
          />

          <Select
            label='Penerima Tugas'
            placeholder='Pilih penerima tugas'
            required
            searchable
            mt='md'
            value={form.data.assigned_to_user_id}
            onChange={value => updateValue('assigned_to_user_id', value)}
            data={usersWithAccessToProject.map(i => ({
              value: i.id.toString(),
              label: i.name,
            }))}
            error={form.errors.assigned_to_user_id}
          />

          <DateInput
            clearable
            locale="id"
            valueFormat='DD MMM YYYY'
            minDate={new Date()}
            mt='md'
            label='Batas Waktu'
            placeholder='Pilih batas waktu'
            value={form.data.due_on}
            onChange={value => updateValue('due_on', value)}
          />

          <LabelsDropdown
            items={labels}
            selected={form.data.labels}
            onChange={values => updateValue('labels', values)}
            mt='md'
          />

          {/* <NumberInput
            label='Estimasi Waktu'
            mt='md'
            decimalScale={2}
            fixedDecimalScale
            defaultValue={0}
            min={0}
            allowNegative={false}
            step={0.5}
            suffix=' jam'
            onChange={value => updateValue('estimation', value)}
          /> */}

          {/* <Select
            label='Pricing type'
            placeholder='Select pricing type'
            required
            mt='md'
            value={form.data.pricing_type}
            onChange={value => updateValue('pricing_type', value)}
            data={pricingTypes}
            error={form.errors.pricing_type}
          /> */}

          {/* {isFixedPrice ? (
            <NumberInput
              label='Fixed price'
              mt='md'
              decimalScale={2}
              fixedDecimalScale
              defaultValue={0}
              min={0}
              allowNegative={false}
              prefix={currencySymbol}
              onChange={value => updateValue('fixed_price', value)}
              error={form.errors.fixed_price}
            />
          ) : null} */}

          {/* <Checkbox
            label='Billable'
            mt='xl'
            checked={form.data.billable}
            onChange={event => updateValue('billable', event.currentTarget.checked)}
          /> */}

          {/* {!hasRoles(user, ['client']) && (
            <Checkbox
              label='Disembunyikan dari klien'
              mt='md'
              checked={form.data.hidden_from_clients}
              onChange={event => updateValue('hidden_from_clients', event.currentTarget.checked)}
            />
          )} */}
        </div>
      </form>
    </Drawer>
  );
}