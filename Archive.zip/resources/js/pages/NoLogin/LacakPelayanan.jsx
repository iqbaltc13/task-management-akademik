import { useState } from 'react';
import { TextInput, Button, Stepper, Group, Paper, Title, Text, Stack, TypographyStylesProvider } from '@mantine/core';
import { IconX } from '@tabler/icons-react';
import axios from 'axios';
import GuestLayoutWithHeaderMenu from '@/layouts/GuestLayoutWithHeaderMenu';
import { date } from '@/utils/datetime';

const STATUS_STEPS = ['diterima', 'diproses', 'selesai'];

export default function LacakLayanan() {
  const [nomor, setNomor] = useState('');
  const [tracking, setTracking] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleLacak = async () => {
    if (!nomor) return;
    setLoading(true);
    setError(null);
    try {
      const res = await axios.post(route('lacak-pelayanan'), { code: nomor });
      setTracking(res.data);
    } catch (e) {
      setTracking(null);
      setError(e.response?.data?.message || 'Terjadi kesalahan, coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!tracking?.link_file_result) return;
    window.location.href = tracking.link_file_result;
  };

  const isDitolak = tracking?.status === 'ditolak';
  const activeStep = tracking
    ? (isDitolak ? 2 : STATUS_STEPS.indexOf(tracking.status))
    : -1;
  const showDownload = tracking && (tracking.status === 'selesai' || tracking.status === 'ditolak');

  return (
    <GuestLayoutWithHeaderMenu title="Lacak Pelayanan">
      <Paper maw={900} mx="auto" mt={50} p="lg" withBorder radius="md">
        <Title order={3} mb="md">Lacak Status Pelayanan</Title>

        <TextInput
          size="lg"
          placeholder="Masukkan nomor pelayanan/permintaan"
          value={nomor}
          onChange={(e) => setNomor(e.currentTarget.value)}
          error={error}
        />

       <Group justify="space-between" mt="md">
        <Button
          component="a"
          href="https://docs.google.com/forms/d/e/1FAIpQLSePKPUvVEeUnEPJWDeaF5gZzkB4t-NZ4GlesY-37As6FkmAwg/viewform?fbzx=3382822052776950239"
          target="_blank"
          rel="noopener noreferrer"
          variant="light"
          color="blue"
          size="lg"
        >
          Isi Survei Kepuasan Layanan
        </Button>

        <Button size="lg" px={40} loading={loading} onClick={handleLacak}>
          Lacak
        </Button>
      </Group>

        {tracking && (
          <Stack mt={40} gap="lg">
            <Stepper active={activeStep} allowNextStepsSelect={false} color={isDitolak ? 'red' : 'blue'}>
              <Stepper.Step
                label="Diterima"
                description={
                  <>
                    Permintaan diterima
                    {tracking.dates?.diterima && (
                      <Text size="xs" c="dimmed" mt={2}>{date(tracking.dates.diterima)}</Text>
                    )}
                  </>
                }
              />
              <Stepper.Step
                label="Diproses"
                description={
                  <>
                    Sedang diproses
                    {tracking.dates?.diproses && (
                      <Text size="xs" c="dimmed" mt={2}>{date(tracking.dates.diproses)}</Text>
                    )}
                  </>
                }
              />
              <Stepper.Step
                label={isDitolak ? 'Ditolak' : 'Selesai'}
                description={
                  <>
                    {isDitolak ? 'Permintaan ditolak' : 'Pelayanan selesai'}
                    {(isDitolak ? tracking.dates?.ditolak : tracking.dates?.selesai) && (
                      <Text size="xs" c="dimmed" mt={2}>
                        {date(isDitolak ? tracking.dates.ditolak : tracking.dates.selesai)}
                      </Text>
                    )}
                  </>
                }
                color={isDitolak ? 'red' : undefined}
                completedIcon={isDitolak ? <IconX size={18} /> : undefined}
              />
            </Stepper>

            <div>
              <Text fw={500} size="sm" mb={4}>Keterangan</Text>
              {tracking.final_feedback ? (
                <TypographyStylesProvider p={0} fz="sm" c="dimmed">
                  <div dangerouslySetInnerHTML={{ __html: tracking.final_feedback }} />
                </TypographyStylesProvider>
              ) : (
                <Text size="sm" c="dimmed">
                  Belum ada keterangan untuk permintaan ini.
                </Text>
              )}
            </div>

            {showDownload && (
              <Button
                fullWidth
                size="md"
                variant="light"
                disabled={!tracking.link_file_result}
                onClick={handleDownload}
              >
                Download Berkas
              </Button>
            )}
          </Stack>
        )}
      </Paper>
    </GuestLayoutWithHeaderMenu>
  );
}