<?php

namespace App\Models;

use App\Events\Task\TaskGroupUpdateLogCreated;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TaskGroupUpdateLog extends Model
{
    use HasFactory, SoftDeletes;
    const DELETED_AT = 'archived_at';
    protected $table = 'task_group_update_logs';
    protected $guarded = [];

    protected static function booted(): void
    {
        static::created(function (TaskGroupUpdateLog $log) {
            TaskGroupUpdateLogCreated::dispatch($log);
        });
    }

    public function task()
    {
        return $this->belongsTo(Task::class);
    }

    public function oldGroup()
    {
        return $this->belongsTo(TaskGroup::class, 'old_group_id');
    }

    public function newGroup()
    {
        return $this->belongsTo(TaskGroup::class, 'new_group_id');
    }

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
